<section id="featured-services" class="featured-services section">
  <div class="container">
    <div class="row gy-4">
      <?php
      $featuredServices = [
          [
              'icon' => 'bi-eye',
              'title' => 'Vision',
              'description' => 'To be a leading construction company in Indonesia, trusted for delivering world-class pipeline, steel structure, and mechanical solutions.',
              'delay' => 100
          ],
          [
              'icon' => 'bi-bullseye',
              'title' => 'Mission',
              'description' => '
                <ul>
                  <li>Deliver safe, high-quality, and efficient construction services.</li>
                  <li>Build long-term client relationships based on professionalism and integrity.</li>
                  <li>Develop skilled and competitive human resources.</li>
                  <li>Apply the latest technology to improve productivity and quality.</li>
                </ul>
              ',
              'delay' => 200
          ]
      ];
      ?>

      <?php $__currentLoopData = $featuredServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-xl-6 col-md-6" data-aos="fade-up" data-aos-delay="<?php echo e($service['delay']); ?>">
        <div class="service-item position-relative">
          <div class="icon"><i class="bi <?php echo e($service['icon']); ?> icon"></i></div>
          <h4><?php echo e($service['title']); ?></h4>
          <?php echo $service['description']; ?>

        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</section>
<?php /**PATH C:\xampp\htdocs\company-profile\resources\views/sections/featured-services.blade.php ENDPATH**/ ?>