<div class="navbar">
    <div class="container">
        <a href="<?php echo e(url('/')); ?>" class="logo">
            <img src="<?php echo e(asset('assets/img/gls.jpg')); ?>" alt="Logo" style="height:40px;">
        </a>
        <nav class="navmenu">
            <ul>
                <li><a href="<?php echo e(url('#hero')); ?>" class="active">Home</a></li>
                <li><a href="<?php echo e(url('#about')); ?>">About</a></li>
                <li><a href="<?php echo e(url('#services')); ?>">Services</a></li>
                <li><a href="<?php echo e(url('#portfolio')); ?>">Portfolio</a></li>
                <li><a href="<?php echo e(url('#team')); ?>">Team</a></li>
                <li><a href="<?php echo e(url('#contact')); ?>">Contact</a></li>
            </ul>
        </nav>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\company-profile\resources\views/partials/navbar.blade.php ENDPATH**/ ?>