<header id="header" class="header sticky-top">
    <div class="branding d-flex align-items-center">
        <div class="container position-relative d-flex align-items-center justify-content-between">
            <a href="<?php echo e(url('/')); ?>" class="logo">
                    <img src="<?php echo e(asset('assets/img/gls.jpg')); ?>" alt="Logo" style="height:40px;">
                    
            </a>
            <?php echo $__env->make('partials.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>
</header>
<?php /**PATH C:\xampp\htdocs\company-profile\resources\views/partials/header.blade.php ENDPATH**/ ?>