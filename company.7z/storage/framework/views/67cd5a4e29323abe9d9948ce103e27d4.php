<section id="core-values" class="core-values section">
    <div class="container section-title" data-aos="fade-up">
        <p><span class="description-title">Core Values</span></p>
    </div>

    <div class="container">
        <div class="row gy-4 justify-content-center">
            <?php
            $coreValues = [
                [
                    'icon' => 'bi-shield-check',
                    'title' => 'Safety First',
                    'description' => 'Prioritizing work safety in every aspect of our operations.',
                    'delay' => 100
                ],
                [
                    'icon' => 'bi-patch-check',
                    'title' => 'Quality Assurance',
                    'description' => 'Meeting international standards for every project delivered.',
                    'delay' => 200
                ],
                [
                    'icon' => 'bi-clock-history',
                    'title' => 'On-Time Delivery',
                    'description' => 'Punctual project completion is our commitment.',
                    'delay' => 300
                ],
                [
                    'icon' => 'bi-currency-dollar',
                    'title' => 'Cost Efficiency',
                    'description' => 'Providing competitive and effective solutions for our clients.',
                    'delay' => 400
                ],
                [
                    'icon' => 'bi-tree',
                    'title' => 'Sustainability',
                    'description' => 'Environmental awareness in every project we undertake.',
                    'delay' => 500
                ],
            ];
            ?>

            <?php $__currentLoopData = $coreValues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-2 col-md-4 col-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="<?php echo e($value['delay']); ?>">
                <div class="service-item position-relative text-center">
                    <div class="icon mb-2">
                        <i class="bi <?php echo e($value['icon']); ?>" style="font-size:2rem;"></i>
                    </div>
                    <h3 style="font-size:1.1rem;"><?php echo e($value['title']); ?></h3>
                    <p style="font-size:0.95rem;"><?php echo e($value['description']); ?></p>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\company-profile\resources\views/sections/values.blade.php ENDPATH**/ ?>