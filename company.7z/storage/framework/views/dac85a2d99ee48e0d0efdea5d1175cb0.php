<footer id="footer" class="footer">
    

    <div class="container footer-top">
        <div class="row gy-4">
            <div class="col-lg-4 col-md-6 footer-about">
                <a href="<?php echo e(url('/')); ?>" class="logo">
                    <img src="<?php echo e(asset('assets/img/gls.jpg')); ?>" alt="Logo" style="height:40px;">
                    
                </a>
                <div class="footer-contact pt-3">
                    <p><?php echo e(config('site.address.street', 'Jl. Lingkar Selatan, KP Gedong Baya')); ?></p>
                    <p><?php echo e(config('site.address.city', 'Kel. Kalitimbang, Kec. Cibeber, Kota Cilegon, Provinsi Banten 42191')); ?></p>
                    <p class="mt-3"><strong>Phone:</strong> <span><?php echo e(config('site.phone', '+1 5589 55488 55')); ?></span></p>
                    <p><strong>Email:</strong> <span><?php echo e(config('site.contact_email', 'info@example.com')); ?></span></p>
                </div>
            </div>

            

            

            
        </div>
    </div>

    <div class="container copyright text-center mt-4">
        <p>© <span>Copyright</span> <strong class="px-1 sitename"><?php echo e(config('app.name', 'BizLand')); ?></strong> <span>All Rights Reserved</span></p>
        <div class="credits">
            Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a> Distributed by <a href="https://themewagon.com">ThemeWagon</a>
        </div>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\company-profile\resources\views/partials/footer.blade.php ENDPATH**/ ?>