<section id="pricing" class="pricing section">
    <!-- Section Title -->
    <div class="container section-title" data-aos="fade-up">
        <h2>Pricing</h2>
        <p><span>Check our</span> <span class="description-title">Pricing</span></p>
    </div><!-- End Section Title -->

    <div class="container">
        <div class="row gy-3">
            <?php
            $pricingPlans = [
                [
                    'name' => 'Free',
                    'price' => 0,
                    'features' => [
                        'Aida dere',
                        'Nec feugiat nisl',
                        'Nulla at volutpat dola',
                        ['name' => 'Pharetra massa', 'available' => false],
                        ['name' => 'Massa ultricies mi', 'available' => false]
                    ],
                    'featured' => false,
                    'advanced' => false,
                    'delay' => 100
                ],
                [
                    'name' => 'Business',
                    'price' => 19,
                    'features' => [
                        'Aida dere',
                        'Nec feugiat nisl',
                        'Nulla at volutpat dola',
                        'Pharetra massa',
                        ['name' => 'Massa ultricies mi', 'available' => false]
                    ],
                    'featured' => true,
                    'advanced' => false,
                    'delay' => 200
                ],
                [
                    'name' => 'Developer',
                    'price' => 29,
                    'features' => [
                        'Aida dere',
                        'Nec feugiat nisl',
                        'Nulla at volutpat dola',
                        'Pharetra massa',
                        'Massa ultricies mi'
                    ],
                    'featured' => false,
                    'advanced' => false,
                    'delay' => 400
                ],
                [
                    'name' => 'Ultimate',
                    'price' => 49,
                    'features' => [
                        'Aida dere',
                        'Nec feugiat nisl',
                        'Nulla at volutpat dola',
                        'Pharetra massa',
                        'Massa ultricies mi'
                    ],
                    'featured' => false,
                    'advanced' => true,
                    'delay' => 400
                ]
            ];
            ?>

            <?php $__currentLoopData = $pricingPlans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xl-3 col-lg-6" data-aos="fade-up" data-aos-delay="<?php echo e($plan['delay']); ?>">
                <div class="pricing-item <?php echo e($plan['featured'] ? 'featured' : ''); ?>">
                    <?php if($plan['advanced']): ?>
                    <span class="advanced">Advanced</span>
                    <?php endif; ?>
                    <h3><?php echo e($plan['name']); ?></h3>
                    <h4><sup>$</sup><?php echo e($plan['price']); ?><span> / month</span></h4>
                    <ul>
                        <?php $__currentLoopData = $plan['features']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(is_array($feature)): ?>
                        <li class="<?php echo e($feature['available'] ? '' : 'na'); ?>"><?php echo e($feature['name']); ?></li>
                        <?php else: ?>
                        <li><?php echo e($feature); ?></li>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <div class="btn-wrap">
                        <a href="#" class="btn-buy">Buy Now</a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\company-profile\resources\views/sections/pricing.blade.php ENDPATH**/ ?>