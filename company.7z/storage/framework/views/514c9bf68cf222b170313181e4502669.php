<nav id="navmenu" class="navmenu">
    <ul>
        <li><a href="#hero" class="<?php echo e(request()->is('/') ? 'active' : ''); ?>">Home</a></li>
        <li><a href="#about">About</a></li>
        <li><a href="#services">Services</a></li>
        <li><a href="#projects">Projects</a></li>
        
        
        <li><a href="#contact">Contact</a></li>
    </ul>
    <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
</nav>
<?php /**PATH C:\xampp\htdocs\company-profile\resources\views/partials/navigation.blade.php ENDPATH**/ ?>